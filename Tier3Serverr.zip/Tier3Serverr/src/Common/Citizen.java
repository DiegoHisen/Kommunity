package Common;




public class Citizen
{
	
	private String cpr;
	
	
	public Citizen(String cpr)
	{
		this.cpr = cpr;
	}
	
	public Citizen()
	{
		
	}
	
	public String getCpr()
	{
		return cpr;
	}
	
	public void setCpr(String cpr)
	{
		this.cpr = cpr;
	}
	

}
