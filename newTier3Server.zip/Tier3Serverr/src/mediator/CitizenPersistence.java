package mediator;

import Common.User;

public interface CitizenPersistence 
{
	public boolean CheckId(User user);

}
